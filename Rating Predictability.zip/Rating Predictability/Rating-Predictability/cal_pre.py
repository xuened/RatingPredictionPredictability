import numpy as np
import math
import collections

def SampEn(U, m, r):
    def _maxdist(x_i, x_j):
        if len(np.array(x_i).shape) == 1:
            return max([abs(ua - va) for ua, va in zip(x_i, x_j)])
        elif len(np.array(x_i).shape) == 2:
            return max([np.linalg.norm(np.array(ua) - np.array(va)) for ua, va in zip(x_i, x_j)])
        else:
            exit(10086)

    def _phi(m):
        x = [[U[j] for j in range(i, i + m - 1 + 1)] for i in range(N - m + 1)]
        B = [(len([1 for x_j in x if _maxdist(x_i, x_j) <= r]) - 1.0) / (N - m) for x_i in x]
        return (N - m + 1.0) ** (-1) * sum(B)
    N = len(U)
    return -1.5*np.log(_phi(m + 1) / _phi(m))

def actual_entropy(l):
    def contains(small, big):
        for i in range(len(big) - len(small) + 1):
            if big[i:i + len(small)] == small:
                return True
        return False

    n = len(l)
    sequence = [l[0]]
    sum_gamma = 0
    for i in range(1, n):
        for j in range(i + 1, n + 1):
            s = l[i:j]
            if not contains(list(s), sequence):
                sum_gamma += len(s)
                sequence.append(l[i])
                break
    ae = 1 / (sum_gamma / n) * math.log(n, 2)
    return ae

def eqution_entropy(l):
    list_counter = collections.Counter(l)
    all_P = []
    N = len(l)
    for key in list_counter:
        all_P.append(list_counter[key])
    all_P.sort(reverse=True)
    S = 0
    for i in all_P:
        S -= (i / N) * math.log(i / N)
    return S

def getN(l):
    one_user_position_set = set(l)
    one_user_neighbor = []
    for i in range(len(l) - 1):
        one_user_neighbor.append([l[i], l[i + 1]])
    one_position_to_onthers_number = {}
    for neighbor in one_user_neighbor:
        if neighbor[0] in one_position_to_onthers_number:
            temp_position = one_position_to_onthers_number[neighbor[0]]
            temp_position += [neighbor[1]]
            one_position_to_onthers_number[neighbor[0]] = temp_position
        else:
            one_position_to_onthers_number[neighbor[0]] = [neighbor[1]]
    Nr = 0
    for posi in one_position_to_onthers_number:
        temp_length = len(set(one_position_to_onthers_number[posi]))
        if temp_length > Nr:
            Nr = temp_length
    return len(one_user_position_set), Nr

def EasyGetSciencePredictability(In_P, In_N, In_S):
    Pi = [x / 10000 for x in range(int(In_P * 10000), 10000)]
    gap = 1000000000
    result = 10000
    for x in Pi:
        # formula = (((1 - x) / (In_N - 1)) ** (1 - x)) * x ** (0.5*x) - 2 ** (-In_S)
        formula = (((1 - x) / (In_N - 1)) ** (1 - x)) * x ** x - 2 ** (-In_S)
        if abs(formula) < gap:
            gap = abs(formula)
            result = x
    return result

def EasyGetWPredictability(In_P, In_N, In_S, In_W):
    Pi = [x / 10000 for x in range(int(In_P * 10000), 10000)]
    gap = 1000000000
    result = 10000
    In_W.sort()
    w_mean = sum(In_W[2:]) / len(In_W[2:])
    w1 = (In_W[0] + In_W[1]) / 2
    # print('w1: ', w1,' w_mean: ',w_mean)
    for x in Pi:
        formula = (((1 - x) / (In_N - 1)) ** (w_mean * (1 - x))) * x ** (w1 * x) - 2 ** (-In_S)
        # formula = (((1-x)/(In_N-1)) **(1-x))* x**x - 2**(-In_S)
        if abs(formula) < gap:
            gap = abs(formula)
            result = x
    return result

def scale_sequence(sequence, new_max=10):
    sequence = np.array(sequence)
    max_value = np.max(sequence)
    if max_value == 0:
        raise ValueError(" ")
    scaled_sequence = np.round((sequence / max_value) * new_max, 1)
    return scaled_sequence.tolist()

def scale_sequence_item_score(sequence_item_score, new_max=10):
    items = [item for item, _ in sequence_item_score]
    scores = [score for _, score in sequence_item_score]

    items = np.array(items)
    scores = np.array(scores)

    max_item = np.max(items)
    max_score = np.max(scores)

    if max_item == 0:
        raise ValueError("")
    if max_score == 0:
        raise ValueError("")

    scaled_items = np.round((items / max_item) * new_max, 1)
    scaled_scores = np.round((scores / max_score) * new_max, 1)
    scaled_sequence_item_score = list(zip(scaled_items.tolist(), scaled_scores.tolist()))
    return scaled_sequence_item_score

def cal_pre_SampEn(sequence_item, sequence_score, sequence_item_score, W):
    sp_m, sp_r1, sp_r2 = 2, 1 * np.std(sequence_item), 0.1 * np.std(sequence_score)
    S_item = SampEn(sequence_item, sp_m, sp_r1)
    S_item_score = SampEn(sequence_item_score, sp_m, sp_r2)
    S_YgX = S_item_score - S_item
    # N_science, Nr = getN(generated_sequence)
    N_science = 10
    Pi_noW = EasyGetSciencePredictability(0, N_science, S_YgX)
    Pi_W = EasyGetWPredictability(0, N_science, S_YgX, W)
    return Pi_noW, Pi_W


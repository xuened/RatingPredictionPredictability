import numpy as np
from bisect import bisect_left
from sklearn.cluster import KMeans

def GetPoints(data,point_number):
    data_list = []
    for i in data:
        data_list.append([i])
    estimator = KMeans(n_clusters=point_number)
    estimator.fit(data_list)
    centroids = estimator.cluster_centers_
    points = []
    for i in centroids:
        points.append(round(i[0], 1))
    points.sort()
    return points

def GetP(data,points,point_number):
    P_times = [0] * point_number
    for b in data:
        right = bisect_left(points, b)
        if right == point_number:
            P_times[right-1] += 1
            continue
        elif right == 0:
            P_times[0] += 1
            continue
        P_times[right] += (b - points[right - 1]) / (points[right] - points[right - 1])
        P_times[right - 1] += (points[right] - b) / (points[right] - points[right - 1])
    sumP = sum(P_times)
    P = []
    for i in P_times:
        P.append(i / sumP)
    return P

def GetMeanC(P):
    C_forward = [0] * len(P)
    C_backward = [0] * len(P)
    for i in range(1, len(P)):
        C_forward[i] = P[i] * P[i - 1]
    for i in range(len(P) - 1, 0, -1):
        C_backward[i - 1] = P[i] * P[i - 1]

    C_forward.insert(0, C_backward[0])
    C_backward.append(C_forward[-1])

    C = [0] * len(P)
    for i in range(len(C)):
        C[i] = (C_forward[i] + C_backward[i]) / 2
    return np.mean(C)

def Scale(X):
    X_new = []
    mid = np.median(X)
    for i in range(len(X)):
        X_new.append(X[i]/mid)
    return X_new

def GetC(P):
    MeanC = GetMeanC(P)
    C_forward = [0] * len(P)
    C_backward = [0] * len(P)
    for i in range(1, len(P)):
        C_forward[i] = P[i] * P[i - 1] * (1 + C_forward[i - 1]-MeanC)
    for i in range(len(P) - 1, 0, -1):
        C_backward[i - 1] = P[i] * P[i - 1] * (1 + C_backward[i]-MeanC)

    C_forward = Scale(C_forward[1:])
    C_backward = Scale(C_backward[:-1])
    C_forward.insert(0, C_backward[0])
    C_backward.append(C_forward[-1])

    C = [0] * len(P)
    for i in range(len(C)):
        C[i] = (C_forward[i] + C_backward[i]) / 2
    C = [pow(x, 1.0 / 4) for x in C]
    C = Scale(C)
    return C

def GetD(points):
    D_forward = [0] * len(points)
    D_backward = [0] * len(points)
    for i in range(0, len(points) - 1):
        D_forward[i] = points[i + 1] - points[i]
    for i in range(len(points) - 1, 0, -1):
        D_backward[i] = points[i] - points[i - 1]

    if max(D_forward[:-1]) != min(D_forward[:-1]) and max(D_backward[1:]) != min(D_backward[1:]):
        D_forward = Scale(D_forward[:-1])
        D_backward = Scale(D_backward[1:])
        D_forward.append(D_backward[-1])
        D_backward.insert(0, D_forward[0])
        D = [0] * len(points)
        for i in range(len(D)):
            D[i] = (D_forward[i] + D_backward[i]) / 2
        D = Scale(D)
    else:
        D = [1] * len(points)
    return D

def Wscale(W,score_set_size):
    beishu = score_set_size / sum(W)
    new_W = [i * beishu for i in W]
    new_W = [pow(x, 1.0 / 4) for x in new_W]
    return new_W

def GetW(D,S):
    W = [0] * len(D)
    for i in range(len(D)):
        W[i] = D[i] / S[i]
    score_set_size = 10
    W = Wscale(W,score_set_size)
    return W

def cal_para(sequence_score, score_set_size):
    points = GetPoints(sequence_score, score_set_size)
    P = GetP(sequence_score, points, score_set_size)
    C = GetC(P)
    D = GetD(points)
    W = GetW(D, C)
    return W
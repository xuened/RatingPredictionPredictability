from load_data import *
from cal_para import *
from cal_pre import *

def run_real_data(dataset_id,score_set_size):
    sequence_item, sequence_score, sequence_item_score = read_dataset(dataset_id,None,None)
    W = cal_para(sequence_score, score_set_size)
    cal_pre_SampEn(sequence_item, sequence_score, sequence_item_score, W)

def main():
    run_real_data(dataset_id=1,score_set_size=10)

if __name__=='__main__':
    main()



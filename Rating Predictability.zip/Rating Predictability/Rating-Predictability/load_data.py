import pickle
import random
import numpy as np
import os
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

def read_dataset(datasetfuction,In_sequence_length,score_set_size):
    df = pd.read_csv('datasets/modcloth.inter', sep='\t', usecols=[0, 1, 2], skiprows=1,
                     nrows=10000,
                     header=None, names=['user_id', 'item_id', 'rating'], dtype={'user_id': str, 'item_id': str, 'rating': float})

    df['user_id'] = df['user_id'].astype('category').cat.codes + 1
    df['item_id'] = df['item_id'].astype('category').cat.codes + 1

    scaler_user = MinMaxScaler()
    df['user_id'] = scaler_user.fit_transform(df[['user_id']])

    scaler_item = MinMaxScaler()
    df['item_id'] = scaler_item.fit_transform(df[['item_id']])

    sequence_item = df['item_id'].tolist()
    sequence_score = df['rating'].tolist()
    sequence_item_score = list(zip(df['item_id'], df['rating']))
    return sequence_item, sequence_score, sequence_item_score



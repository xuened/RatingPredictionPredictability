.. automodule:: recbole.model.general_recommender.spectralcf
   :members:
   :undoc-members:
   :show-inheritance:

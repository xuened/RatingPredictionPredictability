.. automodule:: recbole.model.sequential_recommender.gru4rec
   :members:
   :undoc-members:
   :show-inheritance:

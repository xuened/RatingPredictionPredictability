.. automodule:: recbole.model.sequential_recommender.fossil
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: recbole.data.dataloader.abstract_dataloader
   :members:
   :undoc-members:
   :show-inheritance:

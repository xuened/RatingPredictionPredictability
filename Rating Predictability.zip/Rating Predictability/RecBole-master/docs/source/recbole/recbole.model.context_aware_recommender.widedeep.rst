.. automodule:: recbole.model.context_aware_recommender.widedeep
   :members:
   :undoc-members:
   :show-inheritance:

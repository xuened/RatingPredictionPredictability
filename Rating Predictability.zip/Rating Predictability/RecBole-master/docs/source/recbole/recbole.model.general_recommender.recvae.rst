.. automodule:: recbole.model.general_recommender.recvae
   :members:
   :undoc-members:
   :show-inheritance:

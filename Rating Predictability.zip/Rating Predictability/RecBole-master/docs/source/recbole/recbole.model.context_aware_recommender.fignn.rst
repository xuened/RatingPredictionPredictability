.. automodule:: recbole.model.context_aware_recommender.fignn
   :members:
   :undoc-members:
   :show-inheritance:

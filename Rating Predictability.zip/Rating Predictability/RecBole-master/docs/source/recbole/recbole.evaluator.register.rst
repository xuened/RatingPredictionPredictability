.. automodule:: recbole.evaluator.register
   :members:
   :undoc-members:
   :show-inheritance:

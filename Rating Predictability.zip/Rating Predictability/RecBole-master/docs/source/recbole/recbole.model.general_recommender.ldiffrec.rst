.. automodule:: recbole.model.general_recommender.ldiffrec
   :members:
   :undoc-members:
   :show-inheritance:
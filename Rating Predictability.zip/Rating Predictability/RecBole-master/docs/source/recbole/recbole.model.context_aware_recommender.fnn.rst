.. automodule:: recbole.model.context_aware_recommender.fnn
   :members:
   :undoc-members:
   :show-inheritance:

recbole.evaluator
=========================

.. toctree::
   :maxdepth: 4

   recbole.evaluator.base_metric
   recbole.evaluator.collector
   recbole.evaluator.evaluator
   recbole.evaluator.metrics
   recbole.evaluator.register
   recbole.evaluator.utils

.. automodule:: recbole.model.sequential_recommender.fpmc
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: recbole.model.context_aware_recommender.eulernet
   :members:
   :undoc-members:
   :show-inheritance:
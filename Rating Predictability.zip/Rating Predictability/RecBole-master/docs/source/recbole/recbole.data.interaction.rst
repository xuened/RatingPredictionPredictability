.. automodule:: recbole.data.interaction
   :members:
   :undoc-members:
   :show-inheritance:

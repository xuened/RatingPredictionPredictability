.. automodule:: recbole.model.general_recommender.multidae
   :members:
   :undoc-members:
   :show-inheritance:

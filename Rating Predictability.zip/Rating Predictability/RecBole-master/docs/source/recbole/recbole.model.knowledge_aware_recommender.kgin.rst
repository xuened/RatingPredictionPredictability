.. automodule:: recbole.model.knowledge_aware_recommender.kgin
   :members:
   :undoc-members:
   :show-inheritance:

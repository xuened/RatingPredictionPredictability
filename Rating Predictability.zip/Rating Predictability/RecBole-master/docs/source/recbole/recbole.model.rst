recbole.model
=====================

.. toctree::
   :maxdepth: 4

   recbole.model.context_aware_recommender
   recbole.model.exlib_recommender
   recbole.model.general_recommender
   recbole.model.knowledge_aware_recommender
   recbole.model.sequential_recommender
   recbole.model.abstract_recommender
   recbole.model.init
   recbole.model.layers
   recbole.model.loss

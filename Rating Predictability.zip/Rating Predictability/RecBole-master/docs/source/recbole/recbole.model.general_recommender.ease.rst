.. automodule:: recbole.model.general_recommender.ease
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: recbole.model.sequential_recommender.shan
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: recbole.model.general_recommender.diffrec
   :members:
   :undoc-members:
   :show-inheritance:
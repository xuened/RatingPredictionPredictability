.. automodule:: recbole.model.sequential_recommender.hrm
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: recbole.model.general_recommender.nncf
   :members:
   :undoc-members:
   :show-inheritance:

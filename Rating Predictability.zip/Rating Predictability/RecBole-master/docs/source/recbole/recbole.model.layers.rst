.. automodule:: recbole.model.layers
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: recbole.model.sequential_recommender.sasrecf
   :members:
   :undoc-members:
   :show-inheritance:

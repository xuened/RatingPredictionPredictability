.. automodule:: recbole.model.general_recommender.dgcf
   :members:
   :undoc-members:
   :show-inheritance:

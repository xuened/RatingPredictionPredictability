.. automodule:: recbole.model.sequential_recommender.caser
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: recbole.model.general_recommender.simplex
   :members:
   :undoc-members:
   :show-inheritance:
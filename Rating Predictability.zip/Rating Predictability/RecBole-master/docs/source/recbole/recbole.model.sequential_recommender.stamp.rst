.. automodule:: recbole.model.sequential_recommender.stamp
   :members:
   :undoc-members:
   :show-inheritance:

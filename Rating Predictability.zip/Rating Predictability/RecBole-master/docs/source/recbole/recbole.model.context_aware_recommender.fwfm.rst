.. automodule:: recbole.model.context_aware_recommender.fwfm
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: recbole.model.sequential_recommender.din
   :members:
   :undoc-members:
   :show-inheritance:

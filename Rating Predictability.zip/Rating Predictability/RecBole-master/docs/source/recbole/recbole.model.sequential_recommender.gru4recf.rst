.. automodule:: recbole.model.sequential_recommender.gru4recf
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: recbole.model.context_aware_recommender.ffm
   :members:
   :undoc-members:
   :show-inheritance:

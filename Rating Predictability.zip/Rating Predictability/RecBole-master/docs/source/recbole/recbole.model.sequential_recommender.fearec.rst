.. automodule:: recbole.model.sequential_recommender.fearec
   :members:
   :undoc-members:
   :show-inheritance:

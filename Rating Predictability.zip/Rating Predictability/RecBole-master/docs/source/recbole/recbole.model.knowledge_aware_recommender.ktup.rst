.. automodule:: recbole.model.knowledge_aware_recommender.ktup
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: recbole.model.general_recommender.slimelastic
   :members:
   :undoc-members:
   :show-inheritance:
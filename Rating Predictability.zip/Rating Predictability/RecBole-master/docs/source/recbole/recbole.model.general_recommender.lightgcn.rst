.. automodule:: recbole.model.general_recommender.lightgcn
   :members:
   :undoc-members:
   :show-inheritance:

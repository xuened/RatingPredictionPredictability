.. automodule:: recbole.model.sequential_recommender.lightsans
   :members:
   :undoc-members:
   :show-inheritance:

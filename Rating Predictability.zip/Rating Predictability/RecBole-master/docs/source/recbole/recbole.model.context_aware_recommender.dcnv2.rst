.. automodule:: recbole.model.context_aware_recommender.dcnv2
   :members:
   :undoc-members:
   :show-inheritance:

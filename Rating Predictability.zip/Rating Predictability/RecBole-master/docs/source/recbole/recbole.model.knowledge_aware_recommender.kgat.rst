.. automodule:: recbole.model.knowledge_aware_recommender.kgat
   :members:
   :undoc-members:
   :show-inheritance:

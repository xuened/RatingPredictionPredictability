.. automodule:: recbole.model.context_aware_recommender.pnn
   :members:
   :undoc-members:
   :show-inheritance:

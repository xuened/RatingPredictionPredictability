'''
python run_recbole.py --model=LR --dataset=book-crossing --config_files=test.yaml
python run_recbole.py --model=LR --dataset=jester --config_files=test.yaml
python run_recbole.py --model=LR --dataset=ml-20m --config_files=test.yaml

'''

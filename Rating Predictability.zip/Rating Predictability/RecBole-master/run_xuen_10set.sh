#!/bin/bash

# 创建包含所有命令的文件
commands=(
    "python run_recbole.py --model=LR --dataset=book-crossing --config_files=test.yaml"
    "python run_recbole.py --model=FM --dataset=book-crossing --config_files=test.yaml"
    "python run_recbole.py --model=NFM --dataset=book-crossing --config_files=test.yaml"
    "python run_recbole.py --model=DeepFM --dataset=book-crossing --config_files=test.yaml"
    "python run_recbole.py --model=xDeepFM --dataset=book-crossing --config_files=test.yaml"
    "python run_recbole.py --model=AFM --dataset=book-crossing --config_files=test.yaml"
    "python run_recbole.py --model=FFM --dataset=book-crossing --config_files=test.yaml"
    "python run_recbole.py --model=FwFM --dataset=book-crossing --config_files=test.yaml"
    "python run_recbole.py --model=FNN --dataset=book-crossing --config_files=test.yaml"
    "python run_recbole.py --model=PNN --dataset=book-crossing --config_files=test.yaml"
    "python run_recbole.py --model=WideDeep --dataset=book-crossing --config_files=test.yaml"
    "python run_recbole.py --model=DCN --dataset=book-crossing --config_files=test.yaml"
    "python run_recbole.py --model=AutoInt --dataset=book-crossing --config_files=test.yaml"
    "python run_recbole.py --model=FiGNN --dataset=book-crossing --config_files=test.yaml"
    "python run_recbole.py --model=EulerNet --dataset=book-crossing --config_files=test.yaml"

    "python run_recbole.py --model=LR --dataset=jester --config_files=test.yaml"
    "python run_recbole.py --model=FM --dataset=jester --config_files=test.yaml"
    "python run_recbole.py --model=NFM --dataset=jester --config_files=test.yaml"
    "python run_recbole.py --model=DeepFM --dataset=jester --config_files=test.yaml"
    "python run_recbole.py --model=xDeepFM --dataset=jester --config_files=test.yaml"
    "python run_recbole.py --model=AFM --dataset=jester --config_files=test.yaml"
    "python run_recbole.py --model=FFM --dataset=jester --config_files=test.yaml"
    "python run_recbole.py --model=FwFM --dataset=jester --config_files=test.yaml"
    "python run_recbole.py --model=FNN --dataset=jester --config_files=test.yaml"
    "python run_recbole.py --model=PNN --dataset=jester --config_files=test.yaml"
    "python run_recbole.py --model=WideDeep --dataset=jester --config_files=test.yaml"
    "python run_recbole.py --model=DCN --dataset=jester --config_files=test.yaml"
    "python run_recbole.py --model=AutoInt --dataset=jester --config_files=test.yaml"
    "python run_recbole.py --model=FiGNN --dataset=jester --config_files=test.yaml"
    "python run_recbole.py --model=EulerNet --dataset=jester --config_files=test.yaml"
)

# 将命令并发执行，限制并发数为3
printf "%s\n" "${commands[@]}" | xargs -I CMD -P 3 bash -c CMD
